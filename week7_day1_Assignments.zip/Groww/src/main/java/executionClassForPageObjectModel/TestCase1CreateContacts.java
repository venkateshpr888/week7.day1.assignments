package executionClassForPageObjectModel;

import org.testng.annotations.Test;

import hooks.BasePage;
import testcase1_ForPageObjectModel.LoginPage1;

public class TestCase1CreateContacts extends BasePage{

	@Test
	public void CreateLead() {
		new LoginPage1()
		.typeUserName1("DemoSalesManager")
		.typePassword1("crmsfa")
		.clickLogin1()
		.clickCRMSFA1()
		.ClickContactsTab1()
		.clickcontact1()
		.typeFirstName1("venkatesh")
		.typeLastName1("Ravi")
		.clickSubmit1()
		.verifyFirstName1();
		
		
		
		
	}
	
}
