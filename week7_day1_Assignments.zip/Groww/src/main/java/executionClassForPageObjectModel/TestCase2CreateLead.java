package executionClassForPageObjectModel;

import org.testng.annotations.Test;

import hooks.BasePage;
import testCase2ForPageObjectModel.LoginPage2;


public class TestCase2CreateLead extends BasePage{

	@Test
	public void CreateLead() {
		new LoginPage2()
		.typeUserName2("DemoSalesManager")
		.typePassword2("crmsfa")
		.clickLogin2()
		.clickCRMSFA2()
		.clickLeadsTab2()
		.clickcreateLead2()
		.typeCompanyName2("TestLeaf")
		.typeFirstName2("venkatesh")
		.typeLastName2("Ravi")
		.typeEmailAddress2("venkatesh@gmail.com")
		.clickSubmit2()
		.verifyFirstName2();
	}}
