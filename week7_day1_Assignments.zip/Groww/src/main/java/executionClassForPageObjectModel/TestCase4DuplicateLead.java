package executionClassForPageObjectModel;

import org.testng.annotations.Test;

import hooks.BasePage;

import testCase4ForPageObjectModel.LoginPageForDuplicate;


public class TestCase4DuplicateLead extends BasePage{

	@Test
	public void DuplicateLead() throws InterruptedException {
		
		new LoginPageForDuplicate()
		.typeUserName4("DemoSalesManager")
		.typePassword4("crmsfa")
		.clickLogin4()
		.clickCRMSFA4()
		.clickLeadsTab4()
		.clickFindLead4()
		.clickEmailTab4()
		.typeEmailAddress4("@gmail")
		.clickFind4()
		.clickFirstName4()
		.clickDuplicateTab4()
		.clickCreateLead4()
		.verifyLeadforDuplicate4();
		
		
		
	}
	
}
