package executionClassForPageObjectModel;

import org.testng.annotations.Test;

import hooks.BasePage;
import screens.LoginPage;
import testCase3ForPageObjectModel.LoginPage3;

public class TestCase3EditLead extends BasePage{

	@Test
	public void CreateLead() {
		
		new LoginPage3()
		.typeUserName3("DemoSalesManager")
		.typePassword3("crmsfa")
		.clickLogin3()
		.clickCRMSFA3()
		.clickLeadsTab3()
		.clickFindLead3()
		.clickFirstLead3()
		.clickEditTab3()
		.changeCompanyName3("LEAF TEST")
		.ClickSubmit3()
		.verifyEditedOrNot3();
		
	}
	
}
