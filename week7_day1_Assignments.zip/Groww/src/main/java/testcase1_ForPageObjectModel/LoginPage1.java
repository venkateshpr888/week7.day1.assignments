package testcase1_ForPageObjectModel;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.FindBys;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import hooks.BasePage;

public class LoginPage1 extends BasePage{
//	public LoginPage(ChromeDriver driver) {
//		this.driver=driver;
//		PageFactory.initElements(driver,this);
//	}
	
	/**
	 * Type the user name in the login screen
	 * @param userId -- The different username to login
	 * @return 
	 */
	
	
//	@FindBy(how=How.ID,using= "username")
//	WebElement eleName;
	public LoginPage1 typeUserName1(String userId) {
		getDriver().findElement(By.id("username")).sendKeys(userId);
		return this;
	}
	
	/**
	 * Type the password in the login screen
	 * @param password -- The different password to login
	 * @return 
	 */

	public LoginPage1 typePassword1(String password) {
		getDriver().findElement(By.id("password")).sendKeys(password);
		return this; 
	}
	
	/**
	 * Click the login button
	 * @return 
	 */
	public HomePage clickLogin1() {
		getDriver().findElement(By.className("decorativeSubmit")).click();
		return new HomePage();
	}

}







