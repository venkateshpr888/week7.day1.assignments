package testcase1_ForPageObjectModel;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import hooks.BasePage;

public class MyContactsPage extends BasePage {
//	public MyLeadsPage(ChromeDriver driver) {
//		this.driver=driver;
//	}
	public CreateContactsPage clickcontact1() {
		getDriver().findElement(By.linkText("Create Contact")).click();	
		return new CreateContactsPage();
	}

}
