package testCase4ForPageObjectModel;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import hooks.BasePage;

public class ViewLeadPage extends BasePage{
//	public CreateLeadPage(ChromeDriver driver) {
//		this.driver=driver;
//	}
	
	

	
public DuplicateLeadPage clickDuplicateTab4() {
	getDriver().findElement(By.xpath("//a[text()='Duplicate Lead']")).click();
	return new DuplicateLeadPage();
}
public ViewLeadPage verifyLeadforDuplicate4() {
	String text3 = getDriver().findElement(By.xpath("//span[@id=\"viewLead_firstName_sp\"]")).getText();
	System.out.println(text3);
	if (text3.equals(text)) {
		System.out.println("the duplicated lead name is same as captured name");
		
	} else {
		System.out.println("the duplicated lead name is NOT same as captured name");
	}
	System.out.println("TC4 Successfull");
	return this;
}
}