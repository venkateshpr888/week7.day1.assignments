package hooks;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.time.Duration;
import java.util.Properties;

import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;

import io.github.bonigarcia.wdm.WebDriverManager;

public class BasePage {
	public static String text;
private static final ThreadLocal<ChromeDriver> tlDriver =new ThreadLocal<ChromeDriver>();
public void setDriver(ChromeDriver driver)
{tlDriver.set(driver);
	}
public ChromeDriver  getDriver()
{
	return tlDriver.get();
	}
	//public  ChromeDriver driver;
	
	@BeforeMethod
	public void launch() throws IOException {
//		Properties prop=new Properties();
//		FileInputStream fis= new FileInputStream(new File("./src/main/resources/application.properties"));
//		
//		prop.load(fis);
//		getDriver().get(prop.getProperty("url"));
//		Properties prop1=new Properties();
//		FileInputStream fis1= new FileInputStream(new File("./src/main/resources/"+lang+".properties"));
//		prop1.load(fis1);
				// driver setup
		WebDriverManager.chromedriver().setup();
		//driver = new ChromeDriver();
		setDriver(new ChromeDriver());
		getDriver().get("http://leaftaps.com/opentaps");
		getDriver().manage().window().maximize();
		getDriver().manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
	}
	
	@AfterMethod
	public void tearDown() {
		getDriver().close();
	}

}
