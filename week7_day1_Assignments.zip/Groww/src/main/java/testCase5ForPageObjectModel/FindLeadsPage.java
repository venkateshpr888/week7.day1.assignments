package testCase5ForPageObjectModel;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import hooks.BasePage;

public class FindLeadsPage extends BasePage {
//	public ViewLeadsPage(ChromeDriver driver) {
//		this.driver=driver;
//	}
	public FindLeadsPage clickEmailTab5() {
		getDriver().findElement(By.xpath("//span[text()='Email']")).click();
		return this;
	}
	public FindLeadsPage typeEmailAddress5(String Eaddress) throws InterruptedException {
		getDriver().findElement(By.xpath("//input[@name='emailAddress']")).sendKeys(Eaddress);
		Thread.sleep(3000);
		return this;
	}
	public FindLeadsPage clickFind5() throws InterruptedException {
		//System.out.println("hi");
		getDriver().findElement(By.xpath("//button[text()='Find Leads']")).click();
		Thread.sleep(3000);
		return this;
	}
	public ViewLeadsPage1 clickFirstName5() throws InterruptedException {
		Thread.sleep(3000);
		text = getDriver().findElement(By.xpath("(//a[@class='linktext'])[4]")).getText();
		System.out.println("orginal Number = "+text);
		getDriver().findElement(By.xpath("(//a[@class='linktext'])[4]")).click();
		return new ViewLeadsPage1();
	}
	

}


