package testCase5ForPageObjectModel;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import hooks.BasePage;

public class ViewLeadsPage1 extends BasePage {
//	public ViewLeadsPage(ChromeDriver driver) {
//		this.driver=driver;
//	}
	public DeleteLeadPage ClickDelete5() throws InterruptedException {
		Thread.sleep(2000);
		getDriver().findElement(By.xpath("(//a[@href='javascript:document.deleteLeadForm.submit()'])")).click();
		
		return new DeleteLeadPage();
	}
	public ViewLeadsPage1 VerifyDeleteLead5() {
		getDriver().findElement(By.xpath("(//button[text()='Find Leads'])")).click();
		String noRec = getDriver().findElement(By.xpath("//div[text()='No records to display']")).getText();
		String orginal="No records to display";
		System.out.println(noRec);
if (noRec.equals(orginal)) {
	System.out.println("Confirmation - Records Deleted");
} else {
	System.out.println("Confirmation - Records NOT Deleted");
}System.out.println("TC5 Successfull");
return this;
	}
}
