package testCase2ForPageObjectModel;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import hooks.BasePage;

public class ViewLeadsPage extends BasePage {
//	public ViewLeadsPage(ChromeDriver driver) {
//		this.driver=driver;
//	}
	public ViewLeadsPage verifyFirstName2() {
		String text = getDriver().findElement(By.id("viewLead_firstName_sp")).getText();
	    System.out.println("First name in Create Lead = "+text);
	    System.out.println("TC2 Successfull");
		return this;
	}

}
